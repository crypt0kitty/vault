---
tags: 🧠️/⚙️
publish: true
aliases: 
created: 2022-08-29 1844
updated: 2022-12-11 0850
---

> "There may be a great fire in our hearts
> yet no one comes to warm themselves by it
> and the passers-by see only a wisp of smoke"
> <span class="signature"> - Vincent Van Gogh </span>

> "It is not uncommon for people to spend their whole life waiting to start living.""
> <span class="signature"> - Eckhart Tolle </span>

> “I don’t think it’s quite that simple.
> Some people never observe anything.
> Life just happens to them.
> They get by on little more than a kind of dumb persistence, and they resist with anger and resentment anything that might lift them out of that false serenity.”
> <span class="signature"> - Frank Herbet</span>

> "Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young."
> <span class="signature"> - Henry Ford</span>

