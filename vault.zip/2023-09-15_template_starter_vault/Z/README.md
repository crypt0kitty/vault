---
created: 2022-12-26 1214
updated: 2023-09-15 1319
---
Please note that much of my vault is out of date and i will be revamping it soon.

There is a lot to catch up on that i have missed due to school and other obligations.

I will be revamping my entire system and improving upon my templates and workflow.

I have considered charging for this template vault in the future but decided i don't have the mental coins to spend on doing that.
So i've decided to keep this vault free and will be improving it more in the near future but if you enjoy the vault and find it useful,
I ask that you express your appreciation with a donation of what you think is fair to give for the value you've received.

⭐️ [Github Sponsors](https://github.com/sponsors/tallguyjenks) (no fees, i get 100% of what you send to me)
[Buy Me A Coffee](https://www.buymeacoffee.com/tallguyjenks) (has fees)
[PayPal](https://paypal.me/tallguyjenks?country.x=US&locale.x=en_US) (has fees)
[Patreon](https://www.patreon.com/bryanjenks?fan_landing=true) (**Heavy** fees)

Enjoy!

🌱️ Bryan