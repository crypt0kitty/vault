<%*
selection = tp.file.selection();
tp.file.rename(selection);
tR += selection
_%>