---
tags: 🧠️/📥️/🎧️/🟥️
publish: true
aliases: 
type: podcast
status: 🟥️
---

- `Type:` [[%]]
- `Tags:` 
- `Podcast:` 
	- `Title:` [[<%tp.file.title%>]]
	- `URL:` 
	- `Host:` 
	- `Guest:` 
- `Publish Date:` 
- `Reviewed Date:` [[<%tp.date.now()%>]]
- `Reference:` 

---

- 
