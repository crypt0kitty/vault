---
tags: 📥️/📜️/🟥️
publish: true
aliases: 
  - {{title}}
  - {{citekey}}
url: {{url}}
doi: {{doi}}
citekey: {{citekey}}
keywords: [{{allTags}}]
authors: [{{authors}}{{directors}}]
type: paper
status: 🟥️
---

<%*
	let title = "{{title}}";
	let date = tp.date.now("YYYY-MM-DD");
	await tp.file.rename(`& ${date} ${title}`);
_%>

> [!meta]+ Metadata
> zotero_link:: {{pdfZoteroLink}}
> abstract:: {{abstractNote}}
{% for relation in relations -%}
{%- if relation.citekey -%}
> related:: {{relation.citekey}}
{% endif -%}
{%- endfor %}

```dataview
TABLE created, updated as modified, tags, type
FROM ""
WHERE related != null
AND contains(related, "{{citekey}}")
```

## Hypothesis:

- 

## Methodology:

- 

## Result(s):

- 

## Summary of key points:

- 

## Notes

| <mark class="hltr-grey">Highlight Color</mark> | Meaning                       |
| ---------------------------------------------- | ----------------------------- |
| <mark class="hltr-red">Red</mark>              | Disagree with Author          |
| <mark class="hltr-orange">Orange</mark>        | Important Point By Author     |
| <mark class="hltr-yellow">Yellow</mark>        | Interesting Point             |
| <mark class="hltr-green">Green</mark>          | Important To Me               |
| <mark class="hltr-blue">Blue</mark>            | Notes After Initial Iteration |
| <mark class="hltr-purple">Purple</mark>        | Literary Note To Lookup Later |

{% for annotation in annotations -%}
    {%- if annotation.annotatedText -%} 
		- <mark class="hltr-{{annotation.colorCategory | lower}}">"{{annotation.annotatedText | escape}}”</mark> [Page {{annotation.page}}](zotero://open-pdf/library/items/{{annotation.attachment.itemKey}}?page={{annotation.page}}&annotation={{annotation.id}})
    {%- endif %} 
    {%- if annotation.imageRelativePath -%}
    ![[{{annotation.imageRelativePath}}]] {%- endif %} 
{% if annotation.comment %} 
	- {{annotation.comment}} 
{% endif %} 
{% endfor -%}

## Context:

==(How this article relates to other work in the field; how it ties in with key issues and findings by others, including yourself)==

- 

## Significance:

==(to the field; in relation to your own work)==

- 

## Important Figures and/or Tables:

==(brief description; page number)==

- 

## Other Comments:

- 

## Cited References 

==to follow up on (cite those obviously related to your topic AND any papers frequently cited by others because those works may well prove to be essential as you develop your own work):==

