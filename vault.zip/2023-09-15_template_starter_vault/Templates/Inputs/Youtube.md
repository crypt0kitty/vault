---
tags: 🧠️/📥️/🎥️/🟥️
publish: true
aliases: 
type: video
status: 🟥️
---

- `Title:` [[<%tp.file.title%>]]
- `Type:` [[+]]
- `Tags:` <%tp.file.cursor(1)%>
- `URL:` <<%tp.file.cursor(2)%>>
- `Channel/Host:` <%tp.file.cursor(3)%>
- `Reference:` 
- `Publish Date:` <%tp.file.cursor(4)%>
- `Reviewed Date:` [[<%tp.date.now()%>]]

---

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/<%tp.file.cursor(5)%>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

---

- 