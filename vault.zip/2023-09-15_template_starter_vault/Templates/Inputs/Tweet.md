---
tags: 🧠️/📥️/🐦️/🟥️
publish: true
aliases: 
type: tweet
status: 🟥️
---

- `Title:` [[<%tp.file.title%>]]
- `Type:` [[!]]
- `Tags:` 
- `Account:` 
	- `Notable Mentions:`
- `Reference:` 
- `Publish Date:` 
- `Reviewed Date:` [[<%tp.date.now()%>]]

---

<center><iframe border=0 frameborder=0 height=300 width=550 src="https://twitframe.com/show?url="></iframe></center>

---

- 