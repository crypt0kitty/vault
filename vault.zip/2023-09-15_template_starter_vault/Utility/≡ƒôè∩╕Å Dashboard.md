---
tags: 🧠️/⚙️
publish: false
aliases: dashboard
cssclass: null
created: 2022-04-30 0909
updated: 2022-11-13 1546
---

# Table Of Contents

---


---

## Tasks

---


```dataviewjs
// find dates based on format [[YYYY-MM-DD]]
const findDated = (task)=>{
 if( !task.completed ) {
  task.link = " " + "[[" + task.path + "|*]]";  
  task.date="";
  const found = task.text.match(/\[\[([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))\]\]/);
  if(found) task.date = moment(found[1]);
  return true;  
 }
}
const myTasks =  dv.pages("").file.tasks.where(t => findDated(t));
dv.header(3,"Overdue");
dv.table(["task","link"], myTasks.filter(t=> moment(t.date).isBefore(moment(),"day")).sort(t=>t.date).map(t=>[t.text, t.link]));
dv.header(3,"Today");
dv.table(["task","link"], myTasks.filter(t=> moment(t.date).isSame(moment(),"day")).sort(t=>t.date).map(t=>[t.text, t.link]));
dv.header(3,"Upcoming");
dv.table(["task","link"], myTasks.filter(t=> moment(t.date).isAfter(moment(),"day")).sort(t=>t.date).map(t=>[t.text, t.link]));
dv.header(3,"Undated");
dv.table(["task","link"], myTasks.filter(t=> !t.date).sort(t=>t.text).map(t=>[t.text, t.link]));
```

---

## On This Day

---

```dataviewjs

let dates = {
  today: new Date(),
  activeFile: new Date(app.workspace.getActiveFile().name.substring(0, 10)),
};

let dateToCompare = dates.today;

function pad(n, width, z) {
  z = z || "0";
  n = n + "";
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}

function formatDate(date) {
  let month = pad(date.getMonth() + 1, 2);
  let day = pad(date.getDate(), 2);
  return `-${month}-${day}`;
}

let openFileDateFormatted = formatDate(dates.activeFile);

function formatDataviewDate(dateObject) {
  let month = pad(dateObject.file.day.month, 2);
  let day = pad(dateObject.file.day.day, 2);

  return `-${month}-${day}`;
}

function onThisDay(dailyNote) {
  return formatDataviewDate(dailyNote) == formatDate(dateToCompare);
}

let pages = dv.pages('"Journal/Daily"').where(onThisDay);
let columns = ["File"];

function render() {
  dates.activeFile = new Date(
    app.workspace.getActiveFile().name.substring(0, 10)
  );

  if (isNaN(dates.activeFile)) {
    dateToCompare = dates.today;
  } else {
    dateToCompare = dates.activeFile;
  }

  pages = dv.pages('"Journal/Daily"').where(onThisDay);

  dv.container.empty();

  dv.header(2, "On this day");
  dv.list(pages.file.link);
}

render();

app.workspace.on("file-open", function cb() {
  render();
});

```

## 2021

```dataviewjs
const calendarData = { 
	year: 2021, // (optional) Defaults to current year
	colors: {   // (optional) Defaults to green
	  red:         ["fb4934"], // first entry is considered default if supplied
	  orange:      ["fe8019"],
	  yellow:      ["fabd2f"],
	  green:       ["b8bb26"],
	  blue:        ["458588"], 
	  pink:        ["d3869b"]
	},
	entries: [] // populated in the DataviewJS loop below
}

//DataviewJS loop
for(let page of dv.pages('"Journal/Daily"').where(p=>p.mood).sort(p=>p.file.name)){ 

	calendarData.entries.push({
		date: page.file.name, // (required) Format YYYY-MM-DD
		intensity: page.mood, // (required) Color intensity for entry, will map intensities automatically
		content: page.mood, // (optional) Add text to the date cell
		color: "red", // (optional) Reference from calendarData.colors. If no color is supplied; colors[0] is used
	})
}

/**
* param1  HTMLElement   DOM reference for calendar rendering
* param2  CalendarData  Calendar data object from above
*/
renderHeatmapCalendar(this.container, calendarData)
```

## 2022


```dataviewjs
const calendarData = { 
	year: 2022, // (optional) Defaults to current year
	colors: {   // (optional) Defaults to green
	  red:         ["fb4934"], // first entry is considered default if supplied
	  orange:      ["fe8019"],
	  yellow:      ["fabd2f"],
	  green:       ["b8bb26"],
	  blue:        ["458588"], 
	  pink:        ["d3869b"]
	},
	entries: [] // populated in the DataviewJS loop below
}

//DataviewJS loop
for(let page of dv.pages('"Journal/Daily"').where(p=>p.mood).sort(p=>p.file.name)){ 

	calendarData.entries.push({
		date: page.file.name, // (required) Format YYYY-MM-DD
		intensity: page.mood, // (required) Color intensity for entry, will map intensities automatically
		content: page.mood, // (optional) Add text to the date cell
		color: "red", // (optional) Reference from calendarData.colors. If no color is supplied; colors[0] is used
	})
}

/**
* param1  HTMLElement   DOM reference for calendar rendering
* param2  CalendarData  Calendar data object from above
*/
renderHeatmapCalendar(this.container, calendarData)
```

## Current

```dataviewjs
const calendarData = { 
	//year: 2022, // (optional) Defaults to current year
	colors: {   // (optional) Defaults to green
	  red:         ["fb4934"], // first entry is considered default if supplied
	  orange:      ["fe8019"],
	  yellow:      ["fabd2f"],
	  green:       ["b8bb26"],
	  blue:        ["458588"], 
	  pink:        ["d3869b"]
	},
	entries: [] // populated in the DataviewJS loop below
}

//DataviewJS loop
for(let page of dv.pages('"Journal/Daily"').where(p=>p.mood).sort(p=>p.file.name)){ 

	calendarData.entries.push({
		date: page.file.name, // (required) Format YYYY-MM-DD
		intensity: page.mood, // (required) Color intensity for entry, will map intensities automatically
		content: page.mood, // (optional) Add text to the date cell
		color: "red", // (optional) Reference from calendarData.colors. If no color is supplied; colors[0] is used
	})
}

/**
* param1  HTMLElement   DOM reference for calendar rendering
* param2  CalendarData  Calendar data object from above
*/
renderHeatmapCalendar(this.container, calendarData)
```